"use client";

import React, { useState, useEffect } from "react";
import { Insight } from "./InsightApi";
import { useInsights } from "./InsightHook"; // Import the useInsights hook

// shadcn/ui Dialog components
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

// Utility to convert uploaded PDF file to Base64
export const convertPdfToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (reader.result && typeof reader.result === "string") {
        // Extract Base64 content
        resolve(reader.result.split(",")[1]);
      } else {
        reject("Failed to convert file to Base64");
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

interface UpdateProps {
  isOpen: boolean;
  onClose: () => void;
  currentInsight: Insight; // We assume existing insight with _id
}

const EditInsight: React.FC<UpdateProps> = ({
  isOpen,
  onClose,
  currentInsight,
}) => {
  const { handleUpdateInsight } = useInsights(); // Use the hook
  const [insightData, setInsightData] = useState<Partial<Insight>>(currentInsight);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Reset local state whenever the parent passes a new insight
  useEffect(() => {
    setInsightData(currentInsight);
  }, [currentInsight]);

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        setSuccessMessage(null);
        onClose(); // Close dialog after successful save
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [successMessage, onClose]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    window.addEventListener("keydown", handleEsc);
    return () => {
      window.removeEventListener("keydown", handleEsc);
    };
  }, [onClose]);

  const handleSave = async () => {
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      let serializedPdf = null;
      if (file) {
        serializedPdf = await convertPdfToBase64(file);
      }

      // Prepare the update payload
      const payload: Partial<Insight> = {
        issuer: insightData.issuer || "",
        name: insightData.name || "",
        published_date: insightData.published_date
          ? new Date(insightData.published_date).toISOString().split("T")[0]
          : "",
        summary: insightData.summary || "",
      };

      // If a new PDF is uploaded, place its Base64 in summary (adjust if needed)
      if (serializedPdf) {
        payload.summary = serializedPdf;
      }

      // Use the hook's update method to update the insight
      await handleUpdateInsight({ ...currentInsight, ...payload });

      setSuccessMessage("Insight updated successfully.");
    } catch (err) {
      console.error("Error updating insight:", err);
      setError("Failed to update insight. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        className="bg-black border border-gray-700 text-white max-w-md w-full p-4 text-xs"
      >
        <DialogHeader>
          <DialogTitle className="text-white text-sm font-semibold">
            Update Insight
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Edit the fields below and click Save to update.
          </DialogDescription>
        </DialogHeader>

        {/* Feedback */}
        {error && <p className="text-red-500 mb-2">{error}</p>}
        {successMessage && (
          <p className="text-green-500 mb-2">{successMessage}</p>
        )}

        {/* Date & Issuer */}
        <div className="grid grid-cols-2 gap-2 mb-2">
          <div>
            <label className="block text-gray-400 mb-1">Date</label>
            <input
              type="date"
              value={insightData.published_date || ""}
              onChange={(e) =>
                setInsightData({
                  ...insightData,
                  published_date: e.target.value,
                })
              }
              className="w-full p-1 border border-gray-600 rounded bg-gray-800 text-white appearance-none text-sm [color-scheme: dark] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-gray-400 mb-1">Issuer</label>
            <input
              type="text"
              value={insightData.issuer || ""}
              onChange={(e) =>
                setInsightData({ ...insightData, issuer: e.target.value })
              }
              className="w-full p-1 border border-gray-600 rounded bg-gray-800 text-white text-sm focus:outline-none"
            />
          </div>
        </div>

        {/* Name */}
        <div className="mb-2">
          <label className="block text-gray-400 mb-1">Name</label>
          <input
            type="text"
            value={insightData.name || ""}
            onChange={(e) =>
              setInsightData({ ...insightData, name: e.target.value })
            }
            className="w-full p-1 border border-gray-600 rounded bg-gray-800 text-white text-sm focus:outline-none"
          />
        </div>

        {/* Summary */}
        <div className="mb-2">
          <label className="block text-gray-400 mb-1">Summary</label>
          <textarea
            rows={4}
            value={insightData.summary || ""}
            onChange={(e) =>
              setInsightData({ ...insightData, summary: e.target.value })
            }
            className="w-full p-1 border border-gray-600 rounded bg-gray-800 text-white text-sm focus:outline-none"
          />
        </div>

        {/* PDF Field */}
        <div className="mb-2">
          <label className="block text-gray-400 mb-1">Replace PDF</label>
          <input
            type="file"
            accept=".pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="w-full p-1 border border-gray-600 rounded bg-gray-800 text-white text-sm focus:outline-none"
          />
        </div>

        <DialogFooter className="flex justify-between pt-4">
          <button
            className={`text-green-400 hover:underline ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
            onClick={handleSave}
            disabled={loading}
          >
            {loading ? "Saving..." : "Save"}
          </button>
          <button
            className="text-red-400 hover:underline"
            onClick={onClose}
            disabled={loading}
          >
            Cancel
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditInsight;
