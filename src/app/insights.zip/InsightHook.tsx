"use client";

import { useState, useCallback } from "react";
import {
  fetchInsights,
  deleteInsight,
  updateInsight,
  updateSummary,
  createInsightWithPDF,
} from "./InsightApi";
import { Insight } from "./InsightApi";
import { useProgress } from "@/context/Progress/ProgressContext";

export const useInsights = () => {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [allInsights, setAllInsights] = useState<Insight[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const [selectedSummary, setSelectedSummary] = useState<string | null>(null);
  const [selectedInsight, setSelectedInsight] = useState<Insight | null>(null);
  const [isFetching, setIsFetching] = useState<boolean>(false);

  const { addTask, updateTask, removeTask, setTaskError } = useProgress();

  const initializeInsights = useCallback(async () => {
    if (isFetching) return; // Prevent duplicate calls
    setIsFetching(true);

    const taskId = addTask("Fetching insights");
    try {
      const data = await fetchInsights({ skip: 0, limit: 100 });
      const filteredData = searchTerm
        ? data.filter((insight) =>
            ["name", "issuer"].some((key) =>
              insight[key as keyof Insight]
                ?.toString()
                .toLowerCase()
                .includes(searchTerm.toLowerCase())
            )
          )
        : data;
      setInsights(filteredData);
      setAllInsights(data);
      updateTask(taskId, true);
    } catch (error) {
      console.error("Error fetching insights:", error);
      setTaskError(taskId, "Failed to fetch insights");
    } finally {
      setIsFetching(false);
      removeTask(taskId);
    }
  }, [addTask, updateTask, removeTask, setTaskError, isFetching, searchTerm]);

  const handleSearch = useCallback(
    (term: string) => {
      setSearchTerm(term);
      setInsights(
        term
          ? allInsights.filter((insight) =>
              ["name", "issuer"].some((key) =>
                insight[key as keyof Insight]
                  ?.toString()
                  .toLowerCase()
                  .includes(term.toLowerCase())
              )
            )
          : allInsights
      );
    },
    [allInsights]
  );

  const handleLoadMore = useCallback(async () => {
    if (isLoadingMore) return; // Prevent duplicate calls

    const taskId = addTask("Loading more insights");
    setIsLoadingMore(true);
    try {
      const moreInsights = await fetchInsights({
        skip: allInsights.length,
        limit: 100,
      });
      const updatedAllInsights = [...allInsights, ...moreInsights];
      const filteredData = searchTerm
        ? updatedAllInsights.filter((insight) =>
            ["name", "issuer"].some((key) =>
              insight[key as keyof Insight]
                ?.toString()
                .toLowerCase()
                .includes(searchTerm.toLowerCase())
            )
          )
        : updatedAllInsights;

      setInsights(filteredData);
      setAllInsights(updatedAllInsights);
      updateTask(taskId, true);
    } catch (error) {
      console.error("Error loading more insights:", error);
      setTaskError(taskId, "Failed to load more insights");
    } finally {
      setIsLoadingMore(false);
      removeTask(taskId);
    }
  }, [
    addTask,
    updateTask,
    removeTask,
    setTaskError,
    allInsights,
    isLoadingMore,
    searchTerm,
  ]);

  const handleDelete = useCallback(
    async (insight: Insight) => {
      // Ensure _id is defined before proceeding
      if (!insight._id) {
        throw new Error("Insight _id is undefined.");
      }
      const taskId = addTask(`Deleting ${insight.name}`);
      try {
        await deleteInsight(insight._id);
        setInsights((prev) => prev.filter((item) => item._id !== insight._id));
        setAllInsights((prev) =>
          prev.filter((item) => item._id !== insight._id)
        );
        updateTask(taskId, true);
      } catch (error) {
        console.error("Error deleting insight:", error);
        setTaskError(taskId, "Failed to delete insight");
      }
    },
    [addTask, updateTask, removeTask, setTaskError]
  );

  const handleUpdateSummary = useCallback(
    async (insight: Insight) => {
      // Ensure _id is defined before proceeding
      if (!insight._id) {
        throw new Error("Insight _id is undefined.");
      }

      const taskId = addTask(`Updating ${insight.name}`);

      try {
        const updatedSummary = await updateSummary(insight._id);
        setInsights((prev) =>
          prev.map((item) =>
            item._id === insight._id
              ? { ...item, summary: updatedSummary }
              : item
          )
        );
        setAllInsights((prev) =>
          prev.map((item) =>
            item._id === insight._id
              ? { ...item, summary: updatedSummary }
              : item
          )
        );
        updateTask(taskId, true);
      } catch (error) {
        console.error("Error updating insight summary:", error);
        setTaskError(taskId, "Failed to update summary");
      }
    },
    [addTask, updateTask, removeTask, setTaskError]
  );

  const handleCreateInsightWithPDF = useCallback(
    async (name: string, base64Content: string) => {
      const taskId = addTask(`Creating new insight: ${name}`);
      try {
        const newInsight = await createInsightWithPDF(base64Content);
        setInsights((prev) => [newInsight, ...prev]);
        setAllInsights((prev) => [newInsight, ...prev]);
        updateTask(taskId, true);
      } catch (error) {
        setTaskError(taskId, "Failed to create new insight");
      }
    },
    [addTask, updateTask, removeTask, setTaskError]
  );

  const handleUpdateInsight = useCallback(
    async (insight: Insight) => {
      // Ensure _id is defined before proceeding
      if (!insight._id) {
        throw new Error("Insight _id is undefined.");
      }
      const taskId = addTask(`Updating insight: ${insight.name}`);
      try {
        const updatedInsight = await updateInsight(insight);

        setInsights((prev) =>
          prev.map((item) =>
            item._id === updatedInsight._id ? updatedInsight : item
          )
        );
        setAllInsights((prev) =>
          prev.map((item) =>
            item._id === updatedInsight._id ? updatedInsight : item
          )
        );

        updateTask(taskId, true);
      } catch (error) {
        console.error("Error updating insight:", error);
        setTaskError(taskId, "Failed to update insight");
      }
    },
    [addTask, updateTask, removeTask, setTaskError]
  );

  return {
    insights,
    allInsights,
    searchTerm,
    isLoadingMore,
    selectedSummary,
    selectedInsight,
    initializeInsights,
    handleSearch,
    handleLoadMore,
    handleDelete,
    handleUpdateSummary,
    handleCreateInsightWithPDF,
    handleUpdateInsight,
    setSelectedSummary,
    setSelectedInsight,
  };
};
