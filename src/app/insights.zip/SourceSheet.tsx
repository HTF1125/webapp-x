"use client";

import React, { useState, useEffect } from "react";
import {
  InsightSource,
  fetchInsightSources,
  createInsightSource,
  updateInsightSource,
  deleteInsightSource,
} from "./SouceApi";
import { FaPlus, FaEllipsisV } from "react-icons/fa";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";

const SourceSheet: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const [sources, setSources] = useState<InsightSource[]>([]);
  const [newSource, setNewSource] = useState({
    url: "",
    name: "",
    frequency: "",
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [selectedSource, setSelectedSource] = useState<InsightSource | null>(
    null
  );

  // Load sources from API on mount
  useEffect(() => {
    const loadSources = async () => {
      try {
        const data = await fetchInsightSources();
        const sortedData = data.sort(
          (a, b) =>
            new Date(a.last_visited).getTime() -
            new Date(b.last_visited).getTime()
        );
        setSources(sortedData);
      } catch (error) {
        setFormError("Failed to fetch insight sources.");
      }
    };

    loadSources();
  }, []);

  const formatLastVisited = (date: string) => {
    const lastVisitedDate = new Date(date);
    return lastVisitedDate.toLocaleString([], {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Handle form submission for creating a new source
  const handleCreateSource = async (event: React.FormEvent) => {
    event.preventDefault();
    setFormError(null);

    if (!newSource.url) {
      setFormError("URL is required.");
      return;
    }

    const sourceData: InsightSource = {
      ...newSource,
      name: newSource.name || null,
      frequency: newSource.frequency || null,
    };

    try {
      const createdSource = await createInsightSource(sourceData);
      setSources((prevSources) =>
        [createdSource, ...prevSources].sort(
          (a, b) =>
            new Date(a.last_visited).getTime() -
            new Date(b.last_visited).getTime()
        )
      );
      setNewSource({ url: "", name: "", frequency: "" });
      setDialogOpen(false);
    } catch (error) {
      setFormError("Failed to create the insight source.");
    }
  };

  const handleOpenLink = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const handleDeleteSource = async (id: string) => {
    try {
      await deleteInsightSource(id);
      setSources((prevSources) => prevSources.filter((src) => src._id !== id));
    } catch (error) {
      setFormError("Failed to delete the insight source.");
    }
  };

  const handleUpdateSource = (source: InsightSource) => {
    setSelectedSource(source);
    setNewSource({
      url: source.url,
      name: source.name || "",
      frequency: source.frequency || "",
    });
    setDialogOpen(true);
  };

  const handleUpdateSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!selectedSource) return;

    const updatedSourceData = {
      url: newSource.url,
      name: newSource.name || undefined,
      frequency: newSource.frequency || undefined,
    };

    try {
      const updatedSource = await updateInsightSource(updatedSourceData);
      setSources((prevSources) =>
        prevSources.map((source) =>
          source._id === updatedSource._id ? updatedSource : source
        )
      );
      setDialogOpen(false);
      setSelectedSource(null);
    } catch (error) {
      setFormError("Failed to update the insight source.");
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent
        side="left"
        className="w-[90vw] sm:w-[400px] p-0 bg-black text-white"
      >
        <div className="flex flex-col h-full">
          <SheetHeader className="px-4 py-6 border-b border-gray-800 flex justify-between items-center">
            <SheetTitle className="text-xl font-bold">
              Insight Sources
            </SheetTitle>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="px-3 py-1 text-sm bg-blue-600 text-white hover:bg-blue-700 rounded-md">
                  <FaPlus className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-black border border-gray-700 text-white">
                <DialogHeader>
                  <DialogTitle>Add New Source</DialogTitle>
                  <DialogDescription>
                    Enter the URL, optional name, and frequency below.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateSource} className="space-y-4">
                  <Input
                    type="url"
                    placeholder="Enter URL"
                    value={newSource.url}
                    onChange={(e) =>
                      setNewSource({ ...newSource, url: e.target.value })
                    }
                    className="bg-black border-gray-700 text-white"
                  />
                  <Input
                    type="text"
                    placeholder="Enter Name (optional)"
                    value={newSource.name}
                    onChange={(e) =>
                      setNewSource({ ...newSource, name: e.target.value })
                    }
                    className="bg-black border-gray-700 text-white"
                  />
                  <Input
                    type="text"
                    placeholder="Enter Frequency (optional)"
                    value={newSource.frequency}
                    onChange={(e) =>
                      setNewSource({ ...newSource, frequency: e.target.value })
                    }
                    className="bg-black border-gray-700 text-white"
                  />
                  {formError && (
                    <p className="text-red-500 text-center">{formError}</p>
                  )}
                  <DialogFooter>
                    <Button
                      type="submit"
                      className="px-3 py-1 text-sm bg-white text-black hover:bg-gray-200 rounded-md"
                    >
                      Save
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </SheetHeader>
          <ScrollArea className="flex-grow px-4 py-2">
            <div className="space-y-4">
              {sources.map((source) => (
                <div
                  key={source._id}
                  className="relative bg-gray-900 rounded-lg p-3 transition-all hover:bg-gray-800 cursor-pointer border border-white"
                >
                  <div className="flex items-center space-x-3 mb-2">
                    <img
                      src={`https://www.google.com/s2/favicons?domain=${source.url}`}
                      alt={source.name || "No name"}
                      className="w-6 h-6 rounded"
                    />
                    <h3
                      className="text-sm font-semibold truncate cursor-pointer"
                      onClick={() => handleOpenLink(source.url)}
                    >
                      {source.name || "Unnamed Source"}
                    </h3>
                  </div>
                  <div className="flex space-x-2">
                    <Badge>{formatLastVisited(source.last_visited)}</Badge>
                    {source.frequency && <Badge>{source.frequency}</Badge>}
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger>
                      <FaEllipsisV className="absolute top-3 right-3 text-gray-400 hover:text-white cursor-pointer" />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-black border border-gray-700 text-white">
                      <DropdownMenuItem
                        onClick={() => handleUpdateSource(source)}
                      >
                        Update
                      </DropdownMenuItem>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <DropdownMenuItem>Delete</DropdownMenuItem>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-black border border-gray-700 text-white">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. This will
                              permanently delete the source.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="bg-gray-600 hover:bg-gray-700">
                              Cancel
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteSource(source._id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ))}
              {!sources.length && (
                <p className="text-center text-gray-400">No sources found.</p>
              )}
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default SourceSheet;
