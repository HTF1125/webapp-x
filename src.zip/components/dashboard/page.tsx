import React, { Suspense } from "react";
import { fetchPeriodPerformances } from "./api";
import { TableData, tableGroups } from "./types";
import PeriodSelector from "./PeriodSelector";
import LoadingSpinner from "@/components/LoadingSpinner";
import { PeriodProvider } from "./PeriodContext";
import Section from "../Section";
import PerformanceChart from "@/components/PerformanceChart";

async function fetchAllPerformanceData(): Promise<TableData[]> {
  try {
    const results = await Promise.all(
      tableGroups.map(async (group) => ({
        data: await fetchPeriodPerformances({ group: group.group }),
        title: group.title,
      }))
    );
    return results;
  } catch (error) {
    console.error("Error fetching performance data:", error);
    return [];
  }
}

export default async function DashboardPage() {
  const tables = await fetchAllPerformanceData();

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8">
      <main>
        <PeriodProvider>
          <Section header="Market">
            <div className="flex justify-between items-center mb-4">
              <Suspense fallback={<LoadingSpinner />}>
                <PeriodSelector />
              </Suspense>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
              {tables.map((tableData, index) => (
                <Suspense key={index} fallback={<LoadingSpinner />}>
                  <div className="p-1 rounded-lg shadow hover:shadow-lg transition-shadow">
                    <PerformanceChart tableData={tableData} />
                  </div>
                </Suspense>
              ))}
            </div>
          </Section>
        </PeriodProvider>
      </main>
    </div>
  );
}
