// app/components/signals/SignalChart.tsx

"use client";

import React, { useMemo } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  TimeScale,
  Title,
  Tooltip,
  ChartOptions,
  ChartData,
} from "chart.js";
import { Line } from "react-chartjs-2";
import "chartjs-adapter-date-fns";
import { enUS } from "date-fns/locale";

// Register necessary Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  TimeScale,
  Title,
  Tooltip
);

interface SignalChartProps {
  data: ChartData<"line">;
  title: string; // Title prop
}

const SignalChart: React.FC<SignalChartProps> = ({ data, title }) => {
  // Calculate the date threshold for twelve months ago
  const twelveMonthsAgo = new Date();
  twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);

  // Filter labels and data points within the last twelve months
  const filteredLabels = data.labels?.filter((label) => {
    const date = new Date(label as string);
    return date >= twelveMonthsAgo;
  });

  const filteredDatasets = data.datasets.map((dataset) => ({
    ...dataset,
    data: dataset.data.filter((_, index) => {
      const date = new Date(data.labels![index] as string);
      return date >= twelveMonthsAgo;
    }),
  }));

  const filteredData = {
    ...data,
    labels: filteredLabels,
    datasets: filteredDatasets,
  };

  const options: ChartOptions<"line"> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false, // Disable the legend
      },
      tooltip: {
        enabled: true,
        callbacks: {
          label: (context) => `${context.raw}%`,
        },
      },
    },
    scales: {
      x: {
        type: "time",
        time: {
          unit: "day",
          tooltipFormat: "PP",
        },
        adapters: {
          date: { locale: enUS },
        },
        grid: {
          color: "rgba(255, 255, 255, 0.1)", // Subtle white grid lines
        },
        ticks: {
          color: "white", // White text for x-axis labels
        },
      },
      y: {
        beginAtZero: true,
        grid: {
          color: "rgba(255, 255, 255, 0.1)", // Subtle white grid lines
        },
        ticks: {
          color: "white", // White text for y-axis labels
        },
      },
    },
    elements: {
      line: {
        tension: 0.3,
        borderWidth: 2,
        borderColor: "rgba(255, 255, 255, 0.7)", // White line
      },
      point: {
        radius: 3,
        backgroundColor: (context) => {
          const value = context.raw as number;
          return value >= 0
            ? "rgba(0, 255, 255, 0.8)" // Bright cyan for positive points
            : "rgba(255, 99, 132, 0.8)"; // Bright red for negative points
        },
        borderColor: "white", // White border for points
        borderWidth: 1,
      },
    },
  };

  return (
    <div className="bg-transparent p-4 border border-white rounded-lg shadow-sm">
      <div className="p-4">
        <h3 className="text-sm font-semibold mb-2 text-center text-white">
          {title}
        </h3>
        <div className="h-[160px]">
          <Line data={filteredData} options={options} />
        </div>
      </div>{" "}
    </div>
  );
};

export default SignalChart;
