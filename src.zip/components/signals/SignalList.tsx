"use client";

import React from "react";
import SignalChart from "./SignalChart";

export interface Signal {
  _id: string;
  code: string;
  data: Record<string, number>; // Data entries as date-value pairs
}

interface SignalListProps {
  signals?: Signal[];
  error?: string;
}

const SignalList: React.FC<SignalListProps> = ({ signals, error }) => {
  if (error) {
    return <p className="text-center text-red-400">{error}</p>;
  }

  if (!signals || signals.length === 0) {
    return <p className="text-center text-gray-400">No signals available.</p>;
  }

  return (
    <div className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2">
      {signals.map((signal) => {
        const chartData = {
          labels: Object.keys(signal.data).map((date) => new Date(date)),
          datasets: [
            {
              label: "Signal Value",
              data: Object.values(signal.data),
              borderColor: "white", // White line for chart
              backgroundColor: "rgba(255, 255, 255, 0.1)", // Transparent fill under line
              fill: true, // Fill area under line
            },
          ],
        };

        return (
          <div
            key={signal._id}
            className="bg-transparent border border-white rounded-lg p-4"
          >
            <SignalChart data={chartData} title={signal.code} />
          </div>
        );
      })}
    </div>
  );
};

export default SignalList;
