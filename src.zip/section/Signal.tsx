import React from "react";
import Section from "@/components/Section";
import BorderBox from "@/components/BorderBox";
import SignalChart from "@/components/NewSignalChart";

export interface Signal {
  _id: string;
  code: string;
  data: Record<string, number>;
}

export default async function SignalSection() {
  const API_URL = process.env.API_URL || "";
  const CACHE_DURATION = 60;

  // Fetch Signals from API
  const fetchSignals = async (): Promise<Signal[] | undefined> => {
    try {
      const response = await fetch(
        new URL("/api/data/signals", API_URL).toString(),
        {
          next: { revalidate: CACHE_DURATION },
          headers: {
            "Cache-Control": `max-age=0, s-maxage=${CACHE_DURATION}, stale-while-revalidate`,
          },
        }
      );

      if (!response.ok) {
        console.error("Failed to fetch signals:", response.statusText);
        return undefined;
      }

      const signals: Signal[] = await response.json();
      return signals.map((signal) => ({
        ...signal,
        data: Object.fromEntries(
          Object.entries(signal.data).map(([date, value]) => [date, value])
        ),
      }));
    } catch (error) {
      console.error("Error fetching signals:", error);
      return undefined;
    }
  };

  // Fetch signal data
  const signals = await fetchSignals();

  // Handle error or empty state
  if (!signals || signals.length === 0) {
    return (
      <Section header="Signals">
        <div className="text-center text-gray-400">No signals available.</div>
      </Section>
    );
  }

  // Render SignalChart directly
  return (
    <Section header="Signals">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {signals.map((signal) => {
          const chartData = {
            labels: Object.keys(signal.data).map((date) => new Date(date)), // Convert keys to dates
            datasets: [
              {
                label: "Signal Value",
                data: Object.values(signal.data),
                borderColor: "cyan",
                backgroundColor: "rgba(255, 255, 255, 0.1)",
                fill: true,
              },
            ],
          };

          return (
            <BorderBox>
              <SignalChart data={chartData} title={signal.code} />
            </BorderBox>
          );
        })}
      </div>
    </Section>
  );
}
