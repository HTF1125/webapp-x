import { Insight } from "./types";

const API_URL = process.env.API_URL || "";

// Generalized helper function to handle API requests
async function apiRequest<T>(path: string, options: RequestInit): Promise<T> {
  const url = `${API_URL}${path}`;
  try {
    const response = await fetch(url, options);
    if (!response.ok) {
      const errorMessage = await response.text();
      throw new Error(`API error: ${response.status} - ${errorMessage}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Error with API request to ${url}:`, error);
    throw new Error("An error occurred while processing your request. Please try again later.");
  }
}

// Fetch insights with optional pagination
export async function fetchInsights(skip = 0, limit = 10): Promise<Insight[]> {
  const path = `/api/data/insights?skip=${skip}&limit=${limit}`;
  return apiRequest<Insight[]>(path, { method: "GET" });
}

// Add a new insight
export async function addInsight(newInsight: Omit<Insight, "_id">): Promise<Insight> {
  const path = "/api/data/insights";
  return apiRequest<Insight>(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(newInsight),
  });
}


// Fetch details of a specific insight by its ID
export async function fetchInsightDetails(id: string): Promise<Insight> {
  const path = `/api/data/insights/${id}`;
  return apiRequest<Insight>(path, {
    method: "GET",
    headers: { "Content-Type": "application/json" },
  });
}
