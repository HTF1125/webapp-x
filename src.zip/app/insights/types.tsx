export interface Insight {
  _id?: string;
  date: string;
  title: string;
  tags: string[];
  content: string;
}
