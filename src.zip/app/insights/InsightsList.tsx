"use client";

import Link from "next/link";
import { useState } from "react";
import { FiPlus, FiCalendar, FiTag, FiArrowRight } from "react-icons/fi";
import { addInsight } from "./api";

interface Insight {
  _id?: string;
  title: string;
  date: string;
  content: string;
  tags: string[];
}

interface InsightsListProps {
  insightHeaders: Insight[];
}

const InsightsList: React.FC<InsightsListProps> = ({ insightHeaders }) => {
  const [error, setError] = useState<string | null>(null);
  const [newInsight, setNewInsight] = useState<Insight>({
    title: "",
    date: new Date().toISOString().split("T")[0],
    content: "",
    tags: [],
  });
  const [insights, setInsights] = useState(insightHeaders);
  const [isAddingInsight, setIsAddingInsight] = useState(false);

  const handleInputChange = (field: keyof Insight, value: string) => {
    setNewInsight((prev) => ({
      ...prev,
      [field]:
        field === "tags" ? value.split(",").map((tag) => tag.trim()) : value,
    }));
  };

  const handleAddInsight = async () => {
    if (!newInsight.title || !newInsight.content) {
      setError("Title and content are required.");
      return;
    }

    try {
      const addedInsight = await addInsight(newInsight);
      setInsights([addedInsight, ...insights]);
      setNewInsight({
        title: "",
        date: new Date().toISOString().split("T")[0],
        content: "",
        tags: [],
      });
      setError(null);
      setIsAddingInsight(false);
    } catch (error) {
      setError("Failed to add insight. Please try again later.");
      console.error(error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <button
        onClick={() => setIsAddingInsight(!isAddingInsight)}
        className="mb-6 flex items-center justify-center w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition duration-300"
      >
        <FiPlus className="mr-2" />
        {isAddingInsight ? "Cancel" : "Add New Insight"}
      </button>

      {isAddingInsight && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">
            Add New Insight
          </h3>
          {error && (
            <p className="text-red-600 bg-red-100 p-3 rounded-lg mb-4">
              {error}
            </p>
          )}
          <div className="space-y-4">
            <input
              type="text"
              value={newInsight.title}
              onChange={(e) => handleInputChange("title", e.target.value)}
              placeholder="Title"
              className="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <input
              type="date"
              value={newInsight.date}
              onChange={(e) => handleInputChange("date", e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <textarea
              value={newInsight.content}
              onChange={(e) => handleInputChange("content", e.target.value)}
              placeholder="Content"
              className="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={5}
            ></textarea>
            <input
              type="text"
              value={newInsight.tags.join(", ")}
              onChange={(e) => handleInputChange("tags", e.target.value)}
              placeholder="Tags (comma-separated)"
              className="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              onClick={handleAddInsight}
              className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition duration-300"
            >
              Add Insight
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {insights.map((insight) => (
          <div
            key={insight._id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-transform transform hover:scale-[1.02]"
          >
            <div className="p-4">
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">
                {insight.title}
              </h2>
              <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-2">
                <FiCalendar className="mr-1" />
                <span>{new Date(insight.date).toLocaleDateString()}</span>
              </div>
              <p className="text-gray-700 dark:text-gray-300 mb-2 line-clamp-3">
                {insight.content}
              </p>
              <div className="flex flex-wrap gap-x-1 gap-y-1 mb-2">
                {insight.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="bg-blue-100 text-blue-800 text-xs font-semibold px-[6px] py-[2px] rounded dark:bg-blue-200 dark:text-blue-800"
                  >
                    <FiTag className="inline mr-1" />
                    {tag}
                  </span>
                ))}
              </div>
              <Link
                href={`/insights/${insight._id}`}
                className="inline-flex items-center text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
              >
                Read more
                <FiArrowRight className="ml-1" />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InsightsList;
