import { fetchInsights } from "./api";
import { Insight } from "./types";
import InsightsList from "./InsightsList";

export default async function InsightsPage() {
  let insights: Insight[] = [];

  try {
    insights = await fetchInsights();
  } catch (error) {
    console.error("Failed to fetch insights:", error);
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-200">Insights</h1>
      </header>
      <InsightsList insightHeaders={insights} />
    </div>
  );
}
