"use client";

import React from "react";
import SignalChart from "./SignalChart";
import { Signal } from "../signals/api"; // Adjust this import path as needed

interface SignalListProps {
  signals: Signal[] | undefined;
  error?: string;
}

const SignalList: React.FC<SignalListProps> = ({ signals, error }) => {
  const startDate = new Date();
  startDate.setFullYear(startDate.getFullYear() - 1);

  if (!signals) {
    return <p className="text-center text-gray-600">No signals available.</p>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">Investment Signals</h2>
      {error? (
        <p className="text-red-500 text-center">{error}</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {signals.map((signal) => {
            const latestEntry = Object.entries(signal.data).reduce(
              (latest, [date, value]) => {
                const currentDate = new Date(date);
                if (!isNaN(currentDate.getTime()) && currentDate > new Date(latest.date)) {
                  return { date, value };
                }
                return latest;
              },
              { date: "", value: "0" }
            );

            const signalType = signal.code.includes("Bullish")? "Bullish" : "Bearish";
            const signalColor = signalType === "Bullish"? "green" : "red";

            return (
              <div
                key={signal._id}
                className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform duration-300 hover:scale-105"
              >
                <div className="p-6">
                  <h3
                    className={`text-xl font-semibold text-center mb-2 ${signalColor}`}
                  >
                    {signal.code}
                  </h3>
                  <p className="text-sm text-center text-gray-600 mb-4">
                    Latest: {latestEntry.date? new Date(latestEntry.date).toLocaleDateString() : 'N/A'} - {latestEntry.value}
                  </p>
                  <SignalChart data={signal.data} startDate={startDate} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default SignalList;
