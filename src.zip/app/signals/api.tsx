export interface Signal {
  _id: string;
  code: string;
  data: Record<string, string>;
}

const API_URL = process.env.API_URL || "";

console.log("API_URL (Signals):", API_URL);

const CACHE_DURATION = 10800;

const cacheOptions: RequestInit = {
  next: { revalidate: CACHE_DURATION },
  headers: {
    "Cache-Control": `max-age=0, s-maxage=${CACHE_DURATION}, stale-while-revalidate`,
  },
};

export async function fetchSignals(): Promise<Signal[] | undefined> {
  const url = new URL("/api/data/signals", API_URL);
  console.log("Fetching signals from URL:", url.toString());

  try {
    const response = await fetch(url.toString(), cacheOptions);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (!Array.isArray(data)) {
      throw new Error("Invalid data format: expected an array of Signal objects");
    }

    return data as Signal[];
  } catch (error) {
    console.error("Error fetching signals:", error);
    throw error;
  }
}
