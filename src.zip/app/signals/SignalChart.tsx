"use client";

import React from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  TimeScale,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import "chartjs-adapter-date-fns";
import { enUS } from "date-fns/locale";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  TimeScale,
  Title,
  Tooltip,
  Legend
);

interface SignalChartProps {
  data: Record<string, string> | undefined;
  startDate: Date;
}

export default function SignalChart({ data, startDate }: SignalChartProps) {
  if (!data) return <div>No data available.</div>;

  const { chartData, chartOptions } = setupChartConfig(data, startDate);

  return (
    <div className="h-64 w-full">
      <Bar data={chartData} options={chartOptions} />
    </div>
  );
}

function setupChartConfig(data: Record<string, string> | undefined, startDate: Date) {
  if (!data) {
    return { chartData: {}, chartOptions: {} };
  }

  const filteredData = Object.entries(data)
   .filter(([date]) =>!isNaN(new Date(date).getTime()) && new Date(date) >= startDate)
   .map(([date, value]) => ({ x: new Date(date), y: parseFloat(value) }));

  const chartData = {
    datasets: [
      {
        label: "Signal Value - Last 1 Year",
        data: filteredData,
        backgroundColor: "rgba(75, 192, 192, 0.6)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'nearest',
      intersect: false,
      axis: 'x'
    },
    scales: {
      x: {
        type: "time" as const,
        time: {
          unit: "month" as const,
          displayFormats: {
            month: "MMM yyyy",
          },
        },
        title: {
          display: true,
          text: "Date",
        },
        adapters: {
          date: {
            locale: enUS,
          },
        },
      },
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: "Value",
        },
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
        callbacks: {
          title: (context: any) => {
            if (context[0].parsed.x) {
              return new Date(context[0].parsed.x).toLocaleDateString("en-US", {
                year: "numeric",
                month: "long",
              });
            }
            return "";
          },
          label: (context: any) => `Value: ${context.parsed.y}`,
        },
      },
      zoom: {
        enabled: false,
      },
    },
  };

  return { chartData, chartOptions };
}
