import { fetchSignals } from "./api";
import SignalList from "./SignalList";

export default async function SignalsPage() {
  try {
    const signals = await fetchSignals();
    if (!signals) {
      throw new Error("No signals available.");
    }
    return <SignalList signals={signals} />;
  } catch (error) {
    console.error("Error fetching signals:", error);
    return <SignalList signals={[]} error="Failed to load signals." />;
  }
}
